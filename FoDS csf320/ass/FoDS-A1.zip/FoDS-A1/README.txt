 
Please install Imagemagick since we are using it to save the gif
